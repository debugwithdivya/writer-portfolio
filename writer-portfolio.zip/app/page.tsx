
'use client'
import WriterPortfolio from './writer-portfolio'

export default function Page() {
  return <WriterPortfolio />
}
