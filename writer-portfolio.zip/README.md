
# Writer Portfolio - Deborah George

This is a ready-to-deploy Next.js + Tailwind project (one-page portfolio + simple Markdown blog).

## Quick start (locally)
1. Install dependencies: `npm install`
2. Run dev server: `npm run dev` (open http://localhost:3000)

## Deploy
- Push this repo to GitHub and connect to Vercel (or run `vercel` from this folder).

## Posts
Add Markdown files to the `posts/` folder. They will appear under `/blog`.
